Twig Extra Bundle
=================

This package is a Symfony bundle that allows to use all "extra" extensions
without any configuration.

Installation
------------

    composer require twig/extra-bundle
