/**
 * Pimcore
 *
 * This source file is available under two different licenses:
 * - GNU General Public License version 3 (GPLv3)
 * - Pimcore Commercial License (PCL)
 * Full copyright and license information is available in
 * LICENSE.md which is distributed with this source code.
 *
 * @copyright  Copyright (c) Pimcore GmbH (http://www.pimcore.org)
 * @license    http://www.pimcore.org/license     GPLv3 and PCL
 */

pimcore.registerNS("pimcore.object.classes.data.numeric");
/**
 * @private
 */
pimcore.object.classes.data.numeric = Class.create(pimcore.object.classes.data.data, {

    type: "numeric",
    /**
     * define where this datatype is allowed
     */
    allowIn: {
        object: true,
        objectbrick: true,
        fieldcollection: true,
        localizedfield: true,
        classificationstore : true,
        block: true,
        encryptedField: true
    },

    initialize: function (treeNode, initData) {
        this.type = "numeric";

        this.initData(initData);

        this.treeNode = treeNode;
    },

    getTypeName: function () {
        return t("numeric");
    },

    getGroup: function () {
            return "numeric";
    },

    getIconClass: function () {
        return "pimcore_icon_numeric";
    },

    getLayout: function ($super) {

        $super();

        this.specificPanel.removeAll();
        var specificItems = this.getSpecificPanelItems(this.datax);
        this.specificPanel.add(specificItems);

        return this.layout;
    },

    getSpecificPanelItems: function (datax, inEncryptedField) {

        const stylingItems = [
            {
                xtype: "textfield",
                fieldLabel: t("width"),
                name: "width",
                value: datax.width
            },
            {
                xtype: "displayfield",
                hideLabel: true,
                value: t('width_explanation')
            }
        ];

        if (this.isInCustomLayoutEditor()) {
            return stylingItems;
        }

        return stylingItems.concat([
            {
                xtype: "numberfield",
                fieldLabel: t("default_value"),
                name: "defaultValue",
                value: datax.defaultValue
            },
            {
                xtype: 'textfield',
                width: 600,
                fieldLabel: t("default_value_generator"),
                labelWidth: 140,
                name: 'defaultValueGenerator',
                value: this.datax.defaultValueGenerator
            },
            {
                xtype: "panel",
                bodyStyle: "padding-top: 3px",
                style: "margin-bottom: 10px",
                html: '<span class="object_field_setting_warning">' + t('inherited_default_value_warning') + '</span>'
            },
            {
                xtype: "numberfield",
                fieldLabel: t("decimal_size"),
                name: "decimalSize",
                maxValue: 65,
                value: datax.decimalSize
            }, {
                xtype: "numberfield",
                fieldLabel: t("decimal_precision"),
                name: "decimalPrecision",
                maxValue: 30,
                value: datax.decimalPrecision,
                listeners: {
                    change: function(field, value) {
                        let minValueComponent = this.specificPanel.getComponent('minValue');
                        let maxValueComponent = this.specificPanel.getComponent('maxValue');

                        if (minValueComponent) {
                            minValueComponent.decimalPrecision = value;
                        }

                        if (maxValueComponent) {
                            maxValueComponent.decimalPrecision = value;
                        }
                    }.bind(this)
                }
            }, {
                xtype: "panel",
                bodyStyle: "padding-top: 3px",
                style: "margin-bottom: 10px",
                html: t('decimal_mysql_type_info')
            }, {
                xtype: "panel",
                bodyStyle: "padding-top: 3px",
                style: "margin-bottom: 10px",
                html: '<span class="object_field_setting_warning">' + t('decimal_mysql_type_naming_warning') + '</span>'
            }, {
                xtype: "checkbox",
                fieldLabel: t("integer"),
                name: "integer",
                checked: datax.integer
            }, {
                xtype: "checkbox",
                fieldLabel: t("only_unsigned"),
                name: "unsigned",
                checked: datax["unsigned"]
            }, {
                xtype: "numberfield",
                fieldLabel: t("min_value"),
                name: "minValue",
                itemId: "minValue",
                decimalPrecision: datax.decimalPrecision || 2,
                value: datax.minValue
            }, {
                xtype: "numberfield",
                fieldLabel: t("max_value"),
                name: "maxValue",
                itemId: "maxValue",
                decimalPrecision: datax.decimalPrecision || 2,
                value: datax.maxValue
            }
        ]);
    },

    applySpecialData: function(source) {
        if (source.datax) {
            if (!this.datax) {
                this.datax =  {};
            }
            Ext.apply(this.datax,
                {
                    width: source.datax.width,
                    defaultValue: source.datax.defaultValue,
                    integer: source.datax.integer,
                    unsigned: source.datax.unsigned,
                    minValue: source.datax.minValue,
                    maxValue: source.datax.maxValue,
                    decimalSize: source.datax.decimalSize,
                    decimalPrecision: source.datax.decimalPrecision,
                    defaultValueGenerator: source.datax.defaultValueGenerator,
                    unique: source.datax.unique
                });
        }
    },

    supportsUnique: function() {
        return true;
    }

});
