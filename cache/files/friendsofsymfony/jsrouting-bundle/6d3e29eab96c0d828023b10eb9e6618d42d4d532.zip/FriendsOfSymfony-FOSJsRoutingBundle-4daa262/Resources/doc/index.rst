FOSJsRoutingBundle
==================

This bundle allows to expose Symfony Routes to JavaScript, so you can generate
relative or absolute URLs in the browser using the same routes as in the backend.

* `Installation <installation.rst>`_
* `Usage <usage.rst>`_
* `Commands <commands.rst>`_
